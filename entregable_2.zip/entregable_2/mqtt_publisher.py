from paho.mqtt import client as mqtt_client
import time
import ssl

# Configuración del cliente MQTT
broker_address = "172.28.128.215"  # Dirección IP de "LAPTOP-EM4849EG"
port = 8883
topic = "test/topic"  

def on_connect(client, userdata, flags, rc, d):
    if rc == 0:
        print("Conectado exitosamente al broker")
    else:
        print(f"Fallo la conexión, código de retorno {rc}")

# Crea una instancia del cliente MQTT
client = mqtt_client.Client(mqtt_client.CallbackAPIVersion.VERSION2)
client.username_pw_set(username="mqtt", password="elur2828")
# Configura TLS/SSL
client.tls_set(ca_certs="/home/imanolanda/entregable_2/certificados/ca.crt",
               certfile="/home/imanolanda/entregable_2/certificados/client.crt",
               keyfile="/home/imanolanda/entregable_2/certificados/client.key")

# Asigna la función de callback para la conexión
client.on_connect = on_connect

# Agrega la configuración para aceptar certificados autofirmados
client.tls_insecure_set(True)
# Conecta al broker
client.connect(broker_address, port=port)

# Inicia el loop para procesar los callbacks
client.loop_start()

# Espera a que se establezca la conexión
time.sleep(1)

# Publica mensajes
try:
    while True:
        mensaje = input("Introduce un mensaje (escribe 'salir' para terminar): ")
        if mensaje.lower() == 'salir':
            break
        client.publish(topic, mensaje)  # Publica en el tópico definido
        print(f"Mensaje '{mensaje}' enviado al tópico '{topic}'")
finally:
    client.loop_stop()
    client.disconnect()

print("Publicador MQTT finalizado.")
