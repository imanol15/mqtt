from paho.mqtt import client as mqtt_client
import ssl

# Configuración del cliente MQTT
broker_address = "172.28.128.215"  # Dirección IP del broker
port = 8883  # Puerto del broker
topic = "test/topic"  # Topic al que suscribirse

# Función de callback al conectarse al broker
def on_connect(client, userdata, flags, rc, properties=None):
    if rc == 0:
        print("Conectado exitosamente al broker")
        client.subscribe(topic)  # Suscripción al topic
    else:
        print(f"Fallo la conexión, código de retorno {rc}")

# Función de callback al recibir un mensaje
def on_message(client, userdata, msg):
    print(f"Mensaje recibido '{msg.payload.decode()}' en el tópico '{msg.topic}'")

# Crea una instancia del cliente MQTT
client = mqtt_client.Client(mqtt_client.CallbackAPIVersion.VERSION2)
client.username_pw_set(username="mqtt", password="elur2828")
# Configura TLS/SSL
client.tls_set(ca_certs="/home/imanolanda/entregable_2/certificados/ca.crt",
               certfile="/home/imanolanda/entregable_2/certificados/client.crt",
               keyfile="/home/imanolanda/entregable_2/certificados/client.key")

# Asigna las funciones de callback
client.on_connect = on_connect
client.on_message = on_message

# Conecta al broker
client.connect(broker_address, port=port)

# Inicia el loop para procesar los callbacks
client.loop_forever()
