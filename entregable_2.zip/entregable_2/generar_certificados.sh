#!/bin/bash

# Configuraciones para los certificados
COUNTRY="ES"
STATE="Alava"
LOCALITY="Vitoria"
ORGANIZATION="Deusto"
COMMON_NAME="172.28.128.215"
DAYS=365

# Directorio donde se almacenarán los certificados
CERT_DIR="certificados"

# Crear directorio para los certificados si no existe
mkdir -p "${CERT_DIR}"
cd "${CERT_DIR}"

# Generar la clave privada de la CA
openssl genpkey -algorithm RSA -out ca.key

# Crear el certificado de la CA
openssl req -x509 -new -nodes -key ca.key -sha256 -days "${DAYS}" -out ca.crt -subj "/C=${COUNTRY}/ST=${STATE}/L=${LOCALITY}/O=${ORGANIZATION}/CN=${COMMON_NAME} CA"

# Generar la clave privada del servidor
openssl genpkey -algorithm RSA -out server.key

# Crear un archivo de configuración para el certificado del servidor
cat > server_cert_config.cnf <<EOF
[ req ]
default_bits        = 2048
prompt              = no
default_md          = sha256
distinguished_name  = dn
req_extensions      = req_ext
x509_extensions     = v3_req

[ dn ]
C=${COUNTRY}
ST=${STATE}
L=${LOCALITY}
O=${ORGANIZATION}
CN=${COMMON_NAME} Server

[ req_ext ]
subjectAltName = @alt_names

[ alt_names ]
IP.1 = ${COMMON_NAME}

[ v3_req ]
basicConstraints = CA:FALSE
keyUsage = digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = @alt_names

EOF

# Crear la solicitud de firma de certificado (CSR) para el servidor
openssl req -new -key server.key -out server.csr -config server_cert_config.cnf

# Firma el CSR con la CA para obtener el certificado del servidor
openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out server.crt -days "${DAYS}" -extfile server_cert_config.cnf -extensions v3_req

# Generar la clave privada del cliente
openssl genpkey -algorithm RSA -out client.key

# Crear la solicitud de firma de certificado (CSR) para el cliente
openssl req -new -key client.key -out client.csr -subj "/C=${COUNTRY}/ST=${STATE}/L=${LOCALITY}/O=${ORGANIZATION}/CN=${COMMON_NAME} Client/"

# Firma el CSR con la CA para obtener el certificado del cliente
openssl x509 -req -in client.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out client.crt -days "${DAYS}"

# Cambiar los permisos de las claves para asegurarlas
chmod 400 ca.key server.key client.key

echo "Certificados y claves generados en $(pwd)"
